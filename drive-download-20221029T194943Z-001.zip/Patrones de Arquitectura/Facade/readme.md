# Facade Python 
> El patron de diseño estructural Facade permite la integracion de una interfaz unificada simplificada a un sistema complejo de clases, bibliotecas o marcos.
> Esto patron de diseño es una parte escencial de los Gang of Four. Por lo tanto proporciona una forma mas facil de acceder a los metodos de los sistemas subyacentes al proporcionar un unico punto de entrada.
