Factory
El metodo factory o fabrica es una patron de diseño creativo que tiene la funcion de crear objetos con una interfaz comun
Es decir supongamos que exite una interfaz y que tiene distintas implementaciones u operaciones a realizar, 
para esto separado de esta seccion existe un componente que crea el objeto en concreto que se necesita.
 